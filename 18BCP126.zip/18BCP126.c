#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main()
{
	FILE *f= fopen("bank-full.csv", "r");
	if(f==NULL)
	{
		printf("\n--> Error! 'Bank' File Not Found!\n");	
		exit(0);
	}
	char ch[1000];
	int count=0;
	char month[12][3], d[12][20][3];
	for(int i=0; i<12; i++)
	{
		for(int k=0; k<20; k++)
		{
			for(int j=0; j<3; j++)
			{
				month[i][j]= 'y';
				d[i][k][j]= 'y';
			}		
		}
	}
	printf("\n** Query(s) of Bank File, which match the condition: \n\n");
	while(fgets(ch,1000,f))
	{	
		int temp=0;
		int whet_ret=0, whet_sin=0, whet_loan=0, mon=0;
		for(int i=0; i<strlen(ch); i++)
		{
			if(ch[i]==';')		
			{
				temp++;
			}
			if(temp==1 && whet_ret==0)
			{
				whet_ret= i+2;
			}
			if(temp==2 && whet_sin==0)	
			{
				whet_sin= i+2;
			}	
			if(temp==7 && whet_loan==0)	
			{
				whet_loan= i+2;
			}	
			if(temp==10 && mon==0)
			{
				mon= i+2;
				break;
			}
		}	
		//printf("%c %c %c\n", ch[whet_ret], ch[whet_sin], ch[whet_loan]);	
		if(ch[whet_ret]!='r' && ch[whet_sin]=='s' && ch[whet_loan]=='y')
		{
			//printf("%c %c %c\n", ch[mon], ch[mon+1], ch[mon+2]);		
			//printf("abc\n");
			if(ch[mon]=='f')
			{
				month[1][0]= ch[mon];
				month[1][1]= ch[mon+1];
				month[1][2]= ch[mon+2];
			}
			else if(ch[mon]=='s')
			{
				month[8][0]= ch[mon];
				month[8][1]= ch[mon+1];
				month[8][2]= ch[mon+2];
			}
			else if(ch[mon]=='j')
			{
				if(ch[mon+1]=='a')
				{
					month[0][0]= ch[mon];
					month[0][1]= ch[mon+1];
					month[0][2]= ch[mon+2];
				}	
				else if(ch[mon+1]=='u')
				{
					if(ch[mon+2]=='n')
					{
						month[5][0]= ch[mon];
						month[5][1]= ch[mon+1];
						month[5][2]= ch[mon+2];
					}
					else 
					{
						month[6][0]= ch[mon];
						month[6][1]= ch[mon+1];
						month[6][2]= ch[mon+2];
					}
				}
			}
			else if(ch[mon]=='m')
			{
				if(ch[mon+2]=='r')
				{
					month[2][0]= ch[mon];
					month[2][1]= ch[mon+1];
					month[2][2]= ch[mon+2];
				}
				else
				{
					month[4][0]= ch[mon];
					month[4][1]= ch[mon+1];
					month[4][2]= ch[mon+2];
				}
			}
			else if(ch[mon]=='a')
			{
				if(ch[mon+1]=='p')
				{
					month[3][0]= ch[mon];
					month[3][1]= ch[mon+1];
					month[3][2]= ch[mon+2];
				}
				else
				{
					month[7][0]= ch[mon];
					month[7][1]= ch[mon+1];
					month[7][2]= ch[mon+2];
				}
			}
			else if(ch[mon]=='o')
			{
				month[9][0]= ch[mon];
				month[9][1]= ch[mon+1];
				month[9][2]= ch[mon+2];
			}
			else if(ch[mon]=='n')
			{
				month[10][0]= ch[mon];
				month[10][1]= ch[mon+1];
				month[10][2]= ch[mon+2];
			}
			else
			{
				month[11][0]= ch[mon];
				month[11][1]= ch[mon+1];
				month[11][2]= ch[mon+2];
			}
			count++;
			printf("%d. ", count);
			for(int i=0; i<strlen(ch); i++)
			{
				if(ch[i]==';')
				{
					printf(",  ");
				}
				else
				{
					printf("%c", ch[i]);
				}
			}
			printf("\n");
		}
    	}
	//printf("\n** Query(s) of Bank File, which match the condition: \n\n");
	/*for(int i=0; i<count; i++)
	{
		printf("%d. ", i+1);
		for(int j=0; j<tmpsize[i]; j++)	
		{
			if(ans[i][j]==';')
			{
				printf(",  ");
			}
			else
			{
				printf("%c", ans[i][j]);
			}
		}
		printf("\n");
	}
	for(int i=0; i<12; i++)
	{
		if(month[i][0]!='y')
		{
			for(int j=0; j<3; j++)
			{
				printf("%c", month[i][j]);
			}
			printf("\n");
		}
	}*/
    	fclose(f);
	float maxi[12]= {-50.0};
	int csize[12]= {0};
	FILE *fp= fopen("forestfires.csv", "r");
	if(fp==NULL)
	{
		printf("\n\n\n--> Error! 'ForestFires' File Not Found!\n");	
		exit(0);
	}
	while(fgets(ch,1000,fp))
	{	
		//printf("x");
		int temp=0;
		int mon=0, day=0, high_s=0, high_e=0;
		for(int i=0; i<strlen(ch); i++)
		{
			if(ch[i]==',')		
			{
				temp++;
			}
			if(temp==2 && mon==0)	
			{
				mon= i+1;
			}
			if(temp==3 && day==0)	
			{
				day= i+1;
			}	
			if(temp==8 && high_s==0)
			{
				high_s= i+1;
			}
			if(temp==9 && high_e==0)
			{
				high_e= i-2;
				break;
			}
		}	
		//printf("%c %c %c\n", ch[day], ch[day+1], ch[day+2]);
		char t[3];
		t[0]= ch[mon];
		t[1]= ch[mon+1];
		t[2]= ch[mon+2];
		int high=0;
		float final= 0.0;
		for(int i=0; i<12; i++)
		{
			//final= 0.0;
			if(t[0]==month[i][0] && t[1]==month[i][1] && t[2]==month[i][2])
			{
				int a1= high_e+2-high_s;
				//printf("%d\n", a1);
				if(a1==1)
				{
					//printf("%c\n", ch[high_s]);
					high= ch[high_s];
					high-=48;
					final= 0.0 + high;
				}
				if(a1==2)
				{
					//printf("%c %c\n", ch[high_s], ch[high_s+1]);
					high= ch[high_s];
					high-=48;
					final= high*10;
					high= ch[high_s+1];
					high-=48;
					final+=high;		
				}
				if(a1==3)
				{
					//printf("%c %c %c\n", ch[high_s], ch[high_s+1], ch[high_s+2]);
					high= ch[high_s];
					high-=48;
					final= high*10;
					high= ch[high_s+2];
					high-=48;
					final+=high;
					final/=10;
				}
				if(a1==4)
				{
					//printf("%c %c %c %c\n", ch[high_s], ch[high_s+1], ch[high_s+2], ch[high_s+3]);
					high= ch[high_s];
					high-=48;
					final= high*100;
					high= ch[high_s+1];
					high-=48;
					final+=(high*10);
					high= ch[high_s+3];
					high-=48;	
					final+=high;
					final/=10;
				}
				if(final==maxi[i])
				{
					csize[i]++;
					d[i][csize[i]-1][0]= ch[day];
					d[i][csize[i]-1][1]= ch[day+1];
					d[i][csize[i]-1][2]= ch[day+2];
				}
				if(final>maxi[i])
				{
					csize[i]=1;
					maxi[i]= final;
					d[i][csize[i]-1][0]= ch[day];
					d[i][csize[i]-1][1]= ch[day+1];
					d[i][csize[i]-1][2]= ch[day+2];
				}
				break;
			}
		}	
    	}
    	printf("\n\n\n^^ Days with maximum temperature for all months, which are present in the above records: \n\n\n");
	for(int i=0; i<12; i++)
	{
		if(csize[i]>0)
		{
			printf("--> ");
			printf("%c%c%c: ", month[i][0], month[i][1], month[i][2]);
		}
		for(int j=0; j<csize[i]; j++)
		{
			if(j!=csize[i]-1)
			{
				printf("%c%c%c, ", d[i][j][0], d[i][j][1], d[i][j][2]);
			}
			else
			{
				printf("%c%c%c.", d[i][j][0], d[i][j][1], d[i][j][2]);
			}
		}
		if(csize[i]>0)
		{
			printf("\n");
			printf("** Maximum Temperature: %.1f\n\n", maxi[i]); 
		}
	}
	fclose(fp);
	return 0;
}
